import babel from 'rollup-plugin-babel';
import babelrc from 'babelrc-rollup';
import istanbul from 'rollup-plugin-istanbul';

let pkg = require('./package.json');
let external = Object.keys(pkg.dependencies).concat(['babel-runtime/regenerator']);

let plugins = [
  babel(babelrc()),
];

let globals = {
  'babel-runtime/regenerator': '_regeneratorRuntime'
};

if (process.env.BUILD !== 'production') {
  plugins.push(istanbul({
    exclude: ['test/**/*', 'node_modules/**/*']
  }));
}

export default {
  entry: 'lib/index.js',
  plugins: plugins,
  external: external,
  globals: globals,
  targets: [
    {
      dest: pkg.main,
      format: 'umd',
      moduleName: 'app',
      sourceMap: true
    },
    {
      dest: pkg.module,
      format: 'es',
      sourceMap: true
    }
  ]
};
