import { multiply } from '../';
import { strictEqual, equal } from 'assert';

describe('app features', () => {
  it('do...', () => {

  });
});
