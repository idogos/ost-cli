const assert = require('assert');
const src = require('..');

describe('app features', () => {
  it('do...', () => {
    let result = 1 + 1;
    assert.equal(result, 2);
  });
});


