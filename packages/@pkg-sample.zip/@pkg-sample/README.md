# pkg

## Basic usage

**development**

```bash
npm install
npm run dev
npm run build
npm run test
```

**coverage**

```
test/
coverage/
```

**publish**

```bash
npm version patch
npm publish // publish usual package
npm publish --access public // publish org scope package (eg. @org/my-pkg)
```

## License

[MIT](LICENSE).


