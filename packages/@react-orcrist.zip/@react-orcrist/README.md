# react-orcirst 

> React ‘s boilerplate 

- branch:master => react + react-router + redux + redux-thunk + webpack
- branch:lite => react + react-router + webpack

### React-Cli 
The `react-orcrist`'s boilerplate is used in `react-ost`'s cli, 
please see [react-ost](https://github.com/shangboyang/react-ost/blob/master/README.md).

```sh
sudo npm i -g react-ost // 全局安装react-ost
react-ost init // 初始化工程
```

### Quickstart

```sh
npm install // 安装依赖
npm run dev // 运行dev环境 浏览器访问：http://localhost:7709/
npm run build // 编译打包
```

### Deploy

实际生产部署请按照实际方案进行，这里内置一个基于nginx的静态资源镜像，用于部署参考。

首先将`docker-compose.yml`的ports替换成你想要的端口号(这里是3000)

```yaml
version: '2'
services:
  react-orcrist:
    container_name: react-orcrist-app
    image: nginx-demo:1.0.1
    build:
      context: ./
      dockerfile: Dockerfile
    ports:
    - '3000:80'
```

执行以下命令开启服务

```bash
npm run build
docker-compose build
docker-compose up -d # 完成服务启动
docker-compose stop # 关闭服务
```



#### React client-side-render boilerplate
Project structure:
```
my-app
├── src
│   ├── components
│   ├── config
│   ├── containers
│   ├── css
│   ├── utils
│   └── app.js
└── build
│   ├── build.js
│   ├── dev-client.js
│   ├── dev-server.js
│   ├── webpack.base.config.js
│   ├── webpack.dev.config.js
│   └── webpack.prod.config.js
├── dist
├── .babelrc
├── .eslintignore
├── .eslintrc.js
├── index.html
├── node_modules
├── server.js
├── .gitignore
├── .editorconfig
├──  README.md
└── package.json
```
