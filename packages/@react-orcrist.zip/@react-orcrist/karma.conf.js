const webpackTestConfig = require('./test/config');

const files = ['test/index.js'];
const coverageDir = 'coverage';
const preprocessors = {
  ['test/index.js']: ['webpack', 'sourcemap']
};

module.exports = function(config) {
  config.set({
    browsers: ['Chrome'],
    frameworks: ['mocha', 'chai'],
    port: 9999,
    files: files,
    exclude: [],
    preprocessors: preprocessors,
    webpack: webpackTestConfig,
    webpackMiddleware: {
      noInfo: true
    },
    reporters: [
      'spec',
      'coverage-istanbul',
    ],
    coverageIstanbulReporter: {
      reports: ['html', 'lcovonly', 'text-summary'],
      dir: `test/${coverageDir}`,
      'report-config': {
        html: { subdir: 'html' },
        lcovonly: { subdir: 'lcov' }
      }
    },
    plugins: [
      require('karma-webpack'),
      require('karma-chai'),
      require('karma-mocha'),
      require('karma-chrome-launcher'),
      require('karma-sourcemap-loader'),
      require('karma-spec-reporter'),
      require("karma-coverage-istanbul-reporter"),
      require('karma-mocha-reporter')
    ],
    colors: true,
    // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
    logLevel: config.LOG_INFO,
    autoWatch: false,
    singleRun: false,
    // how many browser should be started simultaneous
    concurrency: Infinity
  })
}
