import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import route from '@/config/route';
import configureStore from '@/config/store';
import '@/asset/base.less';

require('@/utils/polyfill').execute();

const store = configureStore();
store.subscribe(() => {});

ReactDOM.render(
  <Provider store={store}>{route}</Provider>,
  document.getElementById('app')
);
