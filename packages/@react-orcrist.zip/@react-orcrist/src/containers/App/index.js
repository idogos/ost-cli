import React from 'react';
import Connect from '@/containers/App/connect';
import Plate from '@/components/Plate'
import './style.less';

const App = props => (
  <Plate {...props}>
    {props.children}
  </Plate>
);


export default Connect(App);
