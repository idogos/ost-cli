import {
  FETCH_DATA_START,
  FETCH_DATA_END
} from '@/containers/Agent/constants';

const initialState = {
  fetching: false,
  agentData: []
};

const agentReducer = (state = initialState, action) => {
  let newState = {};
  switch (action.type) {
    case FETCH_DATA_START:
      newState = Object.assign({}, state, {
        fetching: action.fetching
      });
      break;
    case FETCH_DATA_END:
      newState = Object.assign({}, state, {
        agentData: action.data || []
      });
      break;
    default:
      newState = Object.assign({}, state);
  }
  return newState;
};

export default agentReducer;
