import {
  connect
} from 'react-redux';
import {
  bindActionCreators
} from 'redux';
import * as AppActions from '@/containers/App/actions';
import * as AgentActions from '@/containers/Agent/actions';

const agentActions = Object.assign({}, AppActions, AgentActions);
const Connect = (Container) => {
  function mapStateToProps(state) {
    return {
      ...state,
    };
  }

  function mapActionToProps(dispatch) {
    return {
      Actions: bindActionCreators(agentActions, dispatch),
    };
  }

  return connect(mapStateToProps, mapActionToProps)(Container);
};

export default Connect;
