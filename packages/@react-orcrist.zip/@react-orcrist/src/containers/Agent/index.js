import React, { Component } from 'react';
import Connect from '@/containers/Agent/connect';
import Content from '@/components/Content'
import './style.less';

class Agent extends Component {


  componentDidMount() {
    const { Actions } = this.props;
    Actions.fetchData();
  }

  render() {
    return (
      <Content>
        <div className="content-title">Welcome to use react-orcrist!</div>
        <section className="content-text">
          Orcrist was an Elven sword from Gondolin, the mate of Glamdring, which became the sword of Thorin II
          Oakenshield during The Quest of Erebor.
        </section>
        <section className="content-text">
          It was used by Thorin in The Hobbit, and was feared and called Biter by the Goblins.
        </section>
      </Content>
    );
  }
}


export default Connect(Agent);
