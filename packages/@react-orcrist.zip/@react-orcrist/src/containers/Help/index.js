import React, { Component } from 'react';

class Help extends Component {
  render() {
    return null
  }
}

export default Help;
