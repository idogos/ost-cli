import React from 'react';
import {
  Router, hashHistory, applyRouterMiddleware
} from 'react-router';
import { useScroll } from 'react-router-scroll';
import App from '@/containers/App';
import Agent from '@/containers/Agent';
import Help from "@/containers/Help";

const config = [
  {
    path: '/',
    component: App,
    indexRoute: {
      component: Agent
    },
    childRoutes: [
      { path: '/agent', name: 'agent', component: Agent },
      { path: '/help', name: 'help', component: Help }
    ]
  }
];

const route = (
  <Router
    history={hashHistory}
    routes={config}
    render={applyRouterMiddleware(useScroll())}>
  </Router>
);


export default route;
