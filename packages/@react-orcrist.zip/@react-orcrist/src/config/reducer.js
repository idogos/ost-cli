import { combineReducers } from 'redux';
import appReducer from '@/containers/App/reducers';
import agentReducer from '@/containers/Agent/reducers';


const rootReducer = combineReducers({
  appReducer,
  agentReducer
});

export default rootReducer;
