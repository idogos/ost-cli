const autoServer = () => {
  let env = '';
  if(navigator.userAgent.match(/NATIVE_APP/ig)) { // hybirdApp env
    env = 'native;';
  } else {
    switch (true) {
      case !!location.host.match(/(localhost)|(127.0.0.1)/ig): // local env
        env = 'mock;https://www.bing.com';
        break;
      case !!location.host.match(/stg/ig): // test-dev env
        env = 'stage;https://stg.com.cn';
        break;
      case !!location.host.match(/prd/ig): // prod env
        env = 'prod;https://prd.com.cn';
        break;
      default:
    }
  }

  return env;
};
export const port = '3001';
export const origin = 'http://localhost';
export default autoServer();
