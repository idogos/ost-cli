import React from 'react';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import '@/containers/App/style.less';

const Plate = props => <ReactCSSTransitionGroup
  component="div"
  transitionName={
    props.transName || 'right'
  }
  transitionEnterTimeout={1000}
  transitionLeaveTimeout={300}
  style={{ height: '100%', width: '100%' }}>
  <div
    className="cm-plate __animation"
    key={props.location.pathname}
    style={{ height: '100%', width: '100%' }}>
    {props.children}
  </div>

</ReactCSSTransitionGroup>;


export default Plate;
