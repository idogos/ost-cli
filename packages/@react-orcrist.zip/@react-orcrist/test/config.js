const path = require('path');
const paths = require('./paths');

const aliasObj = {};
const includeRoot = paths.includeRoot;
const root = paths.root;

paths.branches.forEach(e => {
  aliasObj[e.alias] = path.resolve(__dirname, `../${includeRoot ? root + '/' : ''}${e.path}`);
});

const ref = {
  '@': path.resolve(__dirname, `../${root}`)
};

module.exports = {
  mode: 'none',
  module: {
    rules: [
      {
        test: /\.js|\.jsx$/,
        use: {
          loader: 'babel-loader',
          options: {
            plugins: ['istanbul']
          }
        },
        include: [
          path.join(__dirname, `../${root}/`),
          path.join(__dirname, '../test/specs/'),
          path.join(__dirname, '../test/utils/')
        ],
        exclude: /node_modules/
      },
      {
        test: /\.less$/,
        loaders: [
          { loader: 'style-loader' },
          { loader: 'css-loader' },
          { loader: 'less-loader' }
        ]
      },
      {
        test: /\.css$/,
        loaders: [
          { loader: 'style-loader' },
          { loader: 'css-loader' }
        ]
      },
      {
        test: /\.(ttf|eot|svg|woff|woff2)(\?.+)?$/,
        loader: 'file-loader?name=static/media/[name].[hash:12].[ext]'
      },
      {
        test: /\.(jpe?g|png|gif)(\?.+)?$/,
        loader: 'file-loader?name=static/media/[name].[hash:12].[ext]&limit=25000'
      },
      {
        test: /\.md$/,
        loader: 'raw-loader'
      }
    ]
  },
  resolve: {
    alias: {
      ...aliasObj,
      ...ref
    }
  },
};
