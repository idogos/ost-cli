// const container = require.context('container/', true, /\/index.js$/);
// container.keys().forEach(container);

const components = require.context('components/', true, /\/index.js$/);
components.keys().forEach(components);
