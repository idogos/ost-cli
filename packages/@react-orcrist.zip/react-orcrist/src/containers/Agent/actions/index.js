import {
  FETCH_DATA_START,
  FETCH_DATA_END
} from '@/containers/Agent/constants';
import request from '@/utils/request';
import { port, origin } from '@/config/env';

const fetchStart = () => ({
  type: FETCH_DATA_START,
  fetching: true
});

const fetchEnd = data => ({
  type: FETCH_DATA_END,
  fetching: false,
  data,
});

export const fetchData = () => (dispatch, getState) => {
  dispatch(fetchStart());
  request('get', `${origin}:${port}/agents`, null)
    .then((data) => {
      dispatch(fetchEnd(data));
    }).catch((err) => {
    dispatch(fetchEnd(err));
  });
};
